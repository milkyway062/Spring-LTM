BG          = "#0e0e12"
SURFACE     = "#16161c"
SURFACE_2   = "#1c1c24"
BORDER      = "#26262f"
BORDER_HI   = "#33333f"
TEXT        = "#e8e6ee"
TEXT_DIM    = "#8a8696"
TEXT_MID    = "#b6b2c2"
ACCENT      = "#ff3b6b"
OK          = "#4ed27a"
WARN        = "#e6a23c"
ERR         = "#e25c5c"
INFO        = "#5b8dd9"
DISABLED    = "#44424e"

CARD_BORDERS = ("#ff3b6b", "#36d4e0", "#e6a23c", "#a86bff", "#4ed27a",
                "#ff8c42", "#36ade0", "#d43bff", "#7aff3b", "#e0365a")

SIDEBAR_W   = 58
HEADER_H    = 34
WIN_W       = 560
WIN_H       = 400

FONT_TITLE  = ("Segoe UI Semibold", 12)
FONT_UI     = ("Segoe UI",          10)
FONT_LABEL  = ("Segoe UI",           9)
FONT_SMALL  = ("Segoe UI",           8)
FONT_STAT   = ("Segoe UI Semibold", 18)
FONT_MONO   = ("Consolas",           9)
FONT_NAV    = ("Segoe UI",           7)

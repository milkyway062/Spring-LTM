from __future__ import annotations
from typing import Any, Callable
import customtkinter as ctk
from macro_gui import theme
from macro_gui.spec import FieldSpec


def build_field(master: ctk.CTkFrame, spec: FieldSpec,
                get: Callable[[], Any], set_: Callable[[Any], None]) -> None:
    row = ctk.CTkFrame(master, corner_radius=0, fg_color="transparent")
    row.pack(fill="x", pady=2)

    ctk.CTkLabel(
        row, text=spec.label,
        font=theme.FONT_LABEL,
        text_color=theme.TEXT_MID,
        width=130, anchor="w",
    ).pack(side="left")

    if spec.kind == "bool":
        var = ctk.BooleanVar(value=bool(get()))

        def _toggle():
            set_(var.get())
            if spec.on_change:
                spec.on_change(var.get())

        ctk.CTkSwitch(
            row, text="", variable=var, command=_toggle,
            button_color=theme.ACCENT,
            progress_color=theme.ACCENT,
            fg_color=theme.BORDER_HI,
        ).pack(side="left")

    else:
        var = ctk.StringVar(value=str(get()))
        show = "*" if spec.kind == "password" else None

        kw: dict = dict(
            textvariable=var,
            font=theme.FONT_UI,
            fg_color=theme.SURFACE,
            border_color=theme.BORDER_HI,
            text_color=theme.TEXT,
        )
        if show:
            kw["show"] = show

        entry = ctk.CTkEntry(row, width=220, **kw)
        entry.pack(side="left")

        def _commit(_=None):
            val: Any = var.get().strip()
            if spec.kind == "int":
                try:
                    val = max(0, int(val))
                except ValueError:
                    val = 0
                var.set(str(val))
            set_(val)
            if spec.on_change:
                spec.on_change(val)

        entry.bind("<Return>",   _commit)
        entry.bind("<FocusOut>", _commit)

    if spec.help:
        ctk.CTkLabel(
            row, text=spec.help,
            font=theme.FONT_SMALL,
            text_color=theme.TEXT_DIM,
        ).pack(side="left", padx=(6, 0))

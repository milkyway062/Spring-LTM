from __future__ import annotations
import threading
import customtkinter as ctk
from macro_gui import theme, icons


class ImageCard(ctk.CTkFrame):
    """Card with image thumbnail, title, subtitle, and colored accent border."""

    def __init__(self, master, title: str, subtitle: str,
                 image_url: str, border_color: str,
                 on_click=None, img_size: tuple[int, int] = (52, 52), **kw):
        super().__init__(
            master,
            corner_radius=8,
            fg_color=theme.SURFACE_2,
            border_width=1,
            border_color=border_color,
            cursor="hand2" if on_click else "arrow",
            **kw,
        )
        self._on_click = on_click
        self._border_color = border_color
        self._img_size = img_size
        self._image_url = image_url

        inner = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=12, pady=10)

        self._img_lbl = ctk.CTkLabel(inner, text="", width=img_size[0], height=img_size[1])
        self._img_lbl.pack(side="left", padx=(0, 10))

        text_col = ctk.CTkFrame(inner, corner_radius=0, fg_color="transparent")
        text_col.pack(side="left", fill="both", expand=True)

        ctk.CTkLabel(
            text_col, text=title,
            font=theme.FONT_UI,
            text_color=theme.TEXT,
            anchor="w",
        ).pack(anchor="w")

        ctk.CTkLabel(
            text_col, text=subtitle,
            font=theme.FONT_LABEL,
            text_color=theme.TEXT_DIM,
            anchor="w",
            wraplength=160,
        ).pack(anchor="w", pady=(2, 0))

        self.bind("<Button-1>", self._click)
        self.bind("<Enter>",    self._enter)
        self.bind("<Leave>",    self._leave)

        threading.Thread(target=self._load_image, daemon=True).start()

    def _load_image(self):
        img = icons.fetch(self._image_url, self._img_size)
        self._img_lbl.after(0, lambda: self._img_lbl.configure(image=img))

    def _click(self, _=None):
        if self._on_click:
            self._on_click()

    def _enter(self, _=None):
        self.configure(fg_color=theme.BORDER)

    def _leave(self, _=None):
        self.configure(fg_color=theme.SURFACE_2)


class StatBlock(ctk.CTkFrame):
    """Large number + small label under it."""

    def __init__(self, master, label: str, **kw):
        super().__init__(master, corner_radius=0, fg_color="transparent", **kw)
        self._var = ctk.StringVar(value="—")
        ctk.CTkLabel(
            self, textvariable=self._var,
            font=theme.FONT_STAT,
            text_color=theme.TEXT,
        ).pack(anchor="w")
        ctk.CTkLabel(
            self, text=label,
            font=("Segoe UI", 7),
            text_color=theme.TEXT_DIM,
        ).pack(anchor="w")

    def set(self, value: str):
        self._var.set(value)

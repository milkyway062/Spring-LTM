from __future__ import annotations
import queue
import tkinter as tk
from typing import Any

import customtkinter as ctk

from macro_gui import theme
from macro_gui.spec import MacroSpec
from macro_gui.widgets.sidebar import SidebarNav
from macro_gui.widgets.header import HeaderBar
from macro_gui.widgets.card import StatBlock

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


class MacroApp:
    def __init__(self, root: ctk.CTk, spec: MacroSpec):
        self.root = root
        self.spec = spec

        self._field_values: dict[str, Any] = {
            f.id: f.default for f in spec.fields
        }
        self._stat_blocks:   dict[str, StatBlock] = {}
        self._action_buttons: dict[str, ctk.CTkButton] = {}
        self._page_frames:   dict[str, ctk.CTkFrame] = {}
        self._active_page:   str | None = None
        self._pulse_state:   bool = False

        # Widgets assigned by page builders
        self._phase_lbl:       ctk.CTkLabel | None = None
        self._log_text:        tk.Text | None = None
        self._update_btn:      ctk.CTkButton | None = None
        self._update_status_lbl: ctk.CTkLabel | None = None

        self._build_window()
        self._build_layout()

        # Activate first page
        if spec.pages:
            self._show_page(spec.pages[0].id)

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._tick()

    # ── window setup ──────────────────────────────────────────────

    def _build_window(self):
        self.root.title(self.spec.title)
        self.root.resizable(False, False)
        self.root.configure(fg_color=theme.BG)
        self.root.geometry(f"{theme.WIN_W}x{theme.WIN_H}")

    # ── layout ────────────────────────────────────────────────────

    def _build_layout(self):
        spec = self.spec

        # Outer container: sidebar | right
        outer = ctk.CTkFrame(self.root, corner_radius=0, fg_color=theme.BG)
        outer.pack(fill="both", expand=True)

        # Sidebar
        page_defs = [(p.id, p.label) for p in spec.pages]
        self._sidebar = SidebarNav(outer, page_defs, self._show_page)
        self._sidebar.pack(side="left", fill="y")

        # Right column: header + content
        right = ctk.CTkFrame(outer, corner_radius=0, fg_color=theme.BG)
        right.pack(side="left", fill="both", expand=True)

        hk_labels = [(h.label, h.key) for h in spec.hotkeys]
        self._header = HeaderBar(
            right,
            title=spec.title,
            version=f"v{spec.version}",
            hotkeys=hk_labels,
        )
        self._header.pack(fill="x")

        # Content area: all page frames stacked, only one visible
        self._content = ctk.CTkFrame(right, corner_radius=0, fg_color=theme.BG)
        self._content.pack(fill="both", expand=True)

        for page in spec.pages:
            f = ctk.CTkScrollableFrame(
                self._content,
                corner_radius=0,
                fg_color=theme.BG,
                scrollbar_button_color=theme.BORDER,
                scrollbar_button_hover_color=theme.BORDER_HI,
            )
            f.place(relx=0, rely=0, relwidth=1.0, relheight=1.0)
            f.place_forget()
            page.builder(f, self)
            self._page_frames[page.id] = f

    # ── navigation ────────────────────────────────────────────────

    def _show_page(self, page_id: str):
        if self._active_page:
            self._page_frames[self._active_page].place_forget()
        self._active_page = page_id
        self._page_frames[page_id].place(relx=0, rely=0,
                                          relwidth=1.0, relheight=1.0)
        self._sidebar.set_active(page_id)

    # ── field handling ────────────────────────────────────────────

    def _set_field(self, field_id: str, value: Any):
        self._field_values[field_id] = value
        spec_field = next((f for f in self.spec.fields if f.id == field_id), None)
        if spec_field and spec_field.on_change:
            spec_field.on_change(value)

    def get_field(self, field_id: str) -> Any:
        return self._field_values.get(field_id)

    # ── actions ───────────────────────────────────────────────────

    def set_action_state(self, action_id: str, enabled: bool):
        btn = self._action_buttons.get(action_id)
        if btn:
            btn.configure(state="normal" if enabled else "disabled")

    def _join_private_server(self):
        import os
        from urllib.parse import urlparse, parse_qs
        code = str(self._field_values.get("private_server", "")).strip()
        if not code:
            self.set_status("No private server set", theme.ERR)
            return
        qs = parse_qs(urlparse(code).query)
        link_code = qs["privateServerLinkCode"][0] if "privateServerLinkCode" in qs else code
        os.startfile(f"roblox://placeId=16146832113&linkCode={link_code}/")

    # ── status ────────────────────────────────────────────────────

    def set_status(self, text: str, dot_color: str):
        self.root.after(0, lambda: self._header.set_status(text, dot_color))

    def set_phase(self, text: str):
        if self._phase_lbl:
            self.root.after(0, lambda: self._phase_lbl.configure(text=text))

    def log(self, msg: str):
        if self.spec.log_queue is not None:
            try:
                self.spec.log_queue.put_nowait(msg)
            except Exception:
                pass

    # ── update page ───────────────────────────────────────────────

    def _on_update(self):
        import threading
        if self._update_btn:
            self._update_btn.configure(state="disabled", text="Checking…")
        if hasattr(self, "_run_update"):
            threading.Thread(target=self._run_update, daemon=True).start()

    def _set_update_status(self, msg: str):
        if self._update_status_lbl:
            self.root.after(0, lambda: self._update_status_lbl.configure(text=msg))

    # ── close ─────────────────────────────────────────────────────

    def _on_close(self):
        if self.spec.on_close:
            self.spec.on_close()
        self.root.destroy()

    # ── tick ──────────────────────────────────────────────────────

    def _tick(self):
        # Update stat blocks
        for s in self.spec.stats:
            blk = self._stat_blocks.get(s.id)
            if blk:
                try:
                    blk.set(s.getter())
                except Exception:
                    pass

        # Status dot pulse (only if getter says running)
        if self.spec.status_getter:
            try:
                text, dot = self.spec.status_getter()
                if "running" in text:
                    self._pulse_state = self._header.pulse_dot(
                        theme.OK, "#3aaa5a", self._pulse_state)
            except Exception:
                pass

        # Drain log queue
        if self._log_text and self.spec.log_queue is not None:
            msgs = []
            try:
                while True:
                    msgs.append(self.spec.log_queue.get_nowait())
            except Exception:
                pass
            if msgs:
                at_bottom = self._log_text.yview()[1] >= 0.99
                self._log_text.configure(state="normal")
                self._log_text.insert("end", "\n".join(msgs) + "\n")
                if at_bottom:
                    self._log_text.see("end")
                self._log_text.configure(state="disabled")

        self.root.after(500, self._tick)

    # ── run ───────────────────────────────────────────────────────

    def run(self):
        self.root.mainloop()

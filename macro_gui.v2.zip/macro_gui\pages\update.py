from __future__ import annotations
import customtkinter as ctk
from macro_gui import theme


def build(frame: ctk.CTkFrame, app) -> None:
    ctk.CTkLabel(
        frame, text="Update",
        font=theme.FONT_TITLE,
        text_color=theme.TEXT,
        anchor="w",
    ).pack(anchor="w", padx=12, pady=(12, 1))
    ctk.CTkLabel(
        frame, text="Check GitHub for the latest version",
        font=theme.FONT_LABEL,
        text_color=theme.TEXT_DIM,
        anchor="w",
    ).pack(anchor="w", padx=12, pady=(0, 8))

    ctk.CTkFrame(frame, height=1, corner_radius=0,
                 fg_color=theme.BORDER).pack(fill="x", padx=12, pady=(0, 10))

    app._update_btn = ctk.CTkButton(
        frame,
        text="Check for Updates",
        command=app._on_update,
        corner_radius=6,
        fg_color=theme.SURFACE_2,
        hover_color=theme.BORDER_HI,
        text_color=theme.TEXT,
        font=theme.FONT_UI,
        width=150, height=30,
    )
    app._update_btn.pack(anchor="w", padx=12, pady=(0, 8))

    app._update_status_lbl = ctk.CTkLabel(
        frame, text="",
        font=theme.FONT_LABEL,
        text_color=theme.TEXT_DIM,
        anchor="w",
    )
    app._update_status_lbl.pack(anchor="w", padx=12)

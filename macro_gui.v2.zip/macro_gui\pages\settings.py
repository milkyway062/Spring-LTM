from __future__ import annotations
import customtkinter as ctk
from macro_gui import theme
from macro_gui.widgets.field import build_field


def build(frame: ctk.CTkFrame, app) -> None:
    spec = app.spec

    ctk.CTkLabel(
        frame, text="Settings",
        font=theme.FONT_TITLE,
        text_color=theme.TEXT,
        anchor="w",
    ).pack(anchor="w", padx=12, pady=(12, 1))
    ctk.CTkLabel(
        frame, text="Configure macro behaviour and integrations",
        font=theme.FONT_LABEL,
        text_color=theme.TEXT_DIM,
        anchor="w",
    ).pack(anchor="w", padx=12, pady=(0, 8))

    ctk.CTkFrame(frame, height=1, corner_radius=0,
                 fg_color=theme.BORDER).pack(fill="x", padx=12)

    fields_frame = ctk.CTkFrame(frame, corner_radius=0, fg_color="transparent")
    fields_frame.pack(fill="x", padx=12, pady=10)

    for f in spec.fields:
        build_field(
            fields_frame, f,
            get=lambda fid=f.id: app._field_values.get(fid, f.default),
            set_=lambda val, fid=f.id: app._set_field(fid, val),
        )

    if any(f.id == "private_server" for f in spec.fields):
        ctk.CTkButton(
            fields_frame,
            text="Join Private Server",
            command=app._join_private_server,
            corner_radius=6,
            fg_color=theme.SURFACE_2,
            hover_color=theme.BORDER_HI,
            text_color=theme.TEXT,
            font=theme.FONT_LABEL,
            width=140, height=28,
        ).pack(anchor="w", pady=(4, 0))

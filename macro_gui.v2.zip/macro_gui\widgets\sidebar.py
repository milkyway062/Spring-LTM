from __future__ import annotations
import tkinter as tk
import customtkinter as ctk
from macro_gui import theme
from macro_gui.icons import NAV_GLYPHS


class SidebarNav(ctk.CTkFrame):
    def __init__(self, master, pages: list[tuple[str, str]], on_select, **kw):
        super().__init__(
            master,
            width=theme.SIDEBAR_W,
            corner_radius=0,
            fg_color=theme.SURFACE,
            **kw,
        )
        self.grid_propagate(False)
        self._on_select = on_select
        self._items: list[_NavItem] = []

        logo = ctk.CTkLabel(
            self, text="◈",
            font=("Segoe UI Semibold", 15),
            text_color=theme.ACCENT,
            width=theme.SIDEBAR_W,
            height=theme.HEADER_H,
        )
        logo.pack(side="top", fill="x")

        _Sep(self).pack(side="top", fill="x", padx=8, pady=(0, 2))

        for page_id, label in pages:
            item = _NavItem(self, page_id, label, self._click)
            item.pack(side="top", fill="x", pady=1)
            self._items.append(item)

    def _click(self, page_id: str):
        self.set_active(page_id)
        self._on_select(page_id)

    def set_active(self, page_id: str):
        for item in self._items:
            item.set_active(item.page_id == page_id)


class _NavItem(ctk.CTkFrame):
    def __init__(self, master, page_id: str, label: str, on_click, **kw):
        super().__init__(
            master,
            corner_radius=0,
            fg_color=theme.SURFACE,
            cursor="hand2",
            **kw,
        )
        self.page_id = page_id
        self._on_click = on_click
        self._active = False

        self._bar = tk.Frame(self, bg=theme.SURFACE, width=3)
        self._bar.pack(side="left", fill="y")

        inner = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
        inner.pack(side="left", fill="both", expand=True, padx=(2, 4), pady=4)

        glyph = NAV_GLYPHS.get(page_id, "•")
        self._glyph_lbl = ctk.CTkLabel(
            inner, text=glyph,
            font=("Segoe UI", 13),
            text_color=theme.TEXT_DIM,
            width=theme.SIDEBAR_W - 8,
        )
        self._glyph_lbl.pack()

        self._text_lbl = ctk.CTkLabel(
            inner, text=label,
            font=theme.FONT_NAV,
            text_color=theme.TEXT_DIM,
        )
        self._text_lbl.pack()

        for w in (self, inner, self._glyph_lbl, self._text_lbl, self._bar):
            w.bind("<Button-1>", self._handle_click)
            w.bind("<Enter>",    self._on_enter)
            w.bind("<Leave>",    self._on_leave)

    def _handle_click(self, _=None):
        self._on_click(self.page_id)

    def _on_enter(self, _=None):
        if not self._active:
            self.configure(fg_color=theme.SURFACE_2)

    def _on_leave(self, _=None):
        if not self._active:
            self.configure(fg_color=theme.SURFACE)

    def set_active(self, active: bool):
        self._active = active
        if active:
            self.configure(fg_color=theme.SURFACE_2)
            self._bar.configure(bg=theme.ACCENT)
            self._glyph_lbl.configure(text_color=theme.ACCENT)
            self._text_lbl.configure(text_color=theme.TEXT)
        else:
            self.configure(fg_color=theme.SURFACE)
            self._bar.configure(bg=theme.SURFACE)
            self._glyph_lbl.configure(text_color=theme.TEXT_DIM)
            self._text_lbl.configure(text_color=theme.TEXT_DIM)


class _Sep(ctk.CTkFrame):
    def __init__(self, master, **kw):
        super().__init__(master, height=1, corner_radius=0,
                         fg_color=theme.BORDER, **kw)

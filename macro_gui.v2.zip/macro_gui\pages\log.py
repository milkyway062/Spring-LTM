from __future__ import annotations
import tkinter as tk
import customtkinter as ctk
from macro_gui import theme


def build(frame: ctk.CTkFrame, app) -> None:
    ctk.CTkLabel(
        frame, text="Log",
        font=theme.FONT_TITLE,
        text_color=theme.TEXT,
        anchor="w",
    ).pack(anchor="w", padx=12, pady=(12, 1))
    ctk.CTkLabel(
        frame, text="Live output from the macro worker",
        font=theme.FONT_LABEL,
        text_color=theme.TEXT_DIM,
        anchor="w",
    ).pack(anchor="w", padx=12, pady=(0, 8))

    ctk.CTkFrame(frame, height=1, corner_radius=0,
                 fg_color=theme.BORDER).pack(fill="x", padx=12, pady=(0, 6))

    text_frame = ctk.CTkFrame(frame, corner_radius=6,
                               fg_color=theme.SURFACE, border_width=1,
                               border_color=theme.BORDER)
    text_frame.pack(fill="both", expand=True, padx=12, pady=(0, 6))

    text = tk.Text(
        text_frame,
        state="disabled", wrap="word",
        font=theme.FONT_MONO,
        bg=theme.SURFACE, fg=theme.TEXT_DIM,
        relief="flat", bd=0,
        padx=8, pady=6,
        insertbackground=theme.TEXT,
        selectbackground=theme.BORDER_HI,
        highlightthickness=0,
    )
    sb = tk.Scrollbar(text_frame, command=text.yview,
                      bg=theme.SURFACE, troughcolor=theme.SURFACE,
                      width=10, relief="flat")
    text.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y")
    text.pack(side="left", fill="both", expand=True)

    app._log_text = text

    ctk.CTkButton(
        frame, text="Clear",
        command=lambda: _clear(text),
        corner_radius=6,
        fg_color=theme.SURFACE_2,
        hover_color=theme.BORDER_HI,
        text_color=theme.TEXT_DIM,
        font=theme.FONT_SMALL,
        width=60, height=24,
    ).pack(anchor="w", padx=12, pady=(0, 8))


def _clear(text: tk.Text):
    text.config(state="normal")
    text.delete("1.0", "end")
    text.config(state="disabled")

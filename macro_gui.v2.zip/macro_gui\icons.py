from __future__ import annotations
import hashlib
import io
import os
import urllib.request
from pathlib import Path
from typing import Optional

from PIL import Image
import customtkinter as ctk

_CACHE_DIR = Path(__file__).parent / "_cache"
_CACHE_DIR.mkdir(exist_ok=True)

_PLACEHOLDER_COLOR = "#26262f"

# Unicode icon glyphs mapped to nav names (fallback when no image needed)
NAV_GLYPHS: dict[str, str] = {
    "run":      "▶",
    "settings": "⚙",
    "log":      "≡",
    "update":   "↑",
}


def _placeholder(size: tuple[int, int]) -> ctk.CTkImage:
    img = Image.new("RGB", size, _PLACEHOLDER_COLOR)
    return ctk.CTkImage(light_image=img, dark_image=img, size=size)


def fetch(url: str, size: tuple[int, int] = (56, 56)) -> ctk.CTkImage:
    key = hashlib.sha1(f"{url}{size}".encode()).hexdigest()
    cache_path = _CACHE_DIR / f"{key}.png"

    if cache_path.exists():
        try:
            img = Image.open(cache_path).convert("RGB").resize(size, Image.LANCZOS)
            return ctk.CTkImage(light_image=img, dark_image=img, size=size)
        except Exception:
            cache_path.unlink(missing_ok=True)

    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "MacroGUI-IconFetcher/1.0"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = resp.read()
        img = Image.open(io.BytesIO(data)).convert("RGB").resize(size, Image.LANCZOS)
        img.save(cache_path)
        return ctk.CTkImage(light_image=img, dark_image=img, size=size)
    except Exception:
        return _placeholder(size)

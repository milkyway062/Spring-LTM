from __future__ import annotations
import customtkinter as ctk
from macro_gui import theme
from macro_gui.widgets.card import StatBlock


def build(frame: ctk.CTkFrame, app) -> None:
    spec = app.spec

    ctk.CTkLabel(
        frame, text="Run",
        font=theme.FONT_TITLE,
        text_color=theme.TEXT,
        anchor="w",
    ).pack(anchor="w", padx=12, pady=(12, 1))
    ctk.CTkLabel(
        frame, text="Start, stop, and monitor the macro",
        font=theme.FONT_LABEL,
        text_color=theme.TEXT_DIM,
        anchor="w",
    ).pack(anchor="w", padx=12, pady=(0, 8))

    _sep(frame)

    btn_row = ctk.CTkFrame(frame, corner_radius=0, fg_color="transparent")
    btn_row.pack(fill="x", padx=12, pady=(10, 0))

    _style_map = {
        "primary": (theme.ACCENT,    "#cc2255"),
        "danger":  (theme.ERR,       "#b04040"),
        "neutral": (theme.SURFACE_2, theme.BORDER_HI),
    }

    for action in spec.actions.values():
        normal, hover = _style_map.get(action.style, _style_map["neutral"])
        btn = ctk.CTkButton(
            btn_row,
            text=action.label,
            command=action.callback,
            corner_radius=6,
            fg_color=normal,
            hover_color=hover,
            text_color=theme.TEXT,
            font=theme.FONT_UI,
            width=84, height=30,
        )
        btn.pack(side="left", padx=(0, 6))
        app._action_buttons[action.id] = btn

    hk_text = "  ".join(f"{h.key.upper()} {h.label}" for h in spec.hotkeys)
    ctk.CTkLabel(
        btn_row, text=hk_text,
        font=theme.FONT_SMALL,
        text_color=theme.TEXT_DIM,
    ).pack(side="right")

    _sep(frame, pady=(10, 0))

    stats_row = ctk.CTkFrame(frame, corner_radius=0, fg_color="transparent")
    stats_row.pack(fill="x", padx=12, pady=10)

    for s in spec.stats:
        blk = StatBlock(stats_row, s.label)
        blk.pack(side="left", padx=(0, 18))
        app._stat_blocks[s.id] = blk

    _sep(frame)

    ctk.CTkLabel(
        frame, text="PHASE",
        font=theme.FONT_SMALL,
        text_color=theme.TEXT_DIM,
        anchor="w",
    ).pack(anchor="w", padx=12, pady=(6, 0))

    app._phase_lbl = ctk.CTkLabel(
        frame, text="—",
        font=theme.FONT_LABEL,
        text_color=theme.TEXT_MID,
        anchor="w",
    )
    app._phase_lbl.pack(anchor="w", padx=12, pady=(1, 8))


def _sep(frame, pady=(0, 0)):
    ctk.CTkFrame(frame, height=1, corner_radius=0,
                 fg_color=theme.BORDER).pack(fill="x", padx=12, pady=pady)
